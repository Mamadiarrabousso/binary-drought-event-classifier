## Results (Images)

![figure_01.jpeg](results/figures/figure_01.jpeg)

![figure_02.png](results/figures/figure_02.png)

![figure_03.jpeg](results/figures/figure_03.jpeg)

![figure_04.png](results/figures/figure_04.png)

![figure_05.png](results/figures/figure_05.png)

![figure_06.png](results/figures/figure_06.png)

![figure_07.png](results/figures/figure_07.png)

![figure_08.png](results/figures/figure_08.png)

